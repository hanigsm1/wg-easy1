**You may:**

* Use this software for yourself;
* Use this software for a company;
* Modify this software, as long as you:
  * Publish the changes on GitHub as an open-source & linked fork;
  * Don't remove any links to the original project or donation pages;

**You may not:**

* Use this software in a commercial product without a license from the original author;